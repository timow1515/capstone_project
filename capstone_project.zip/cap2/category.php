<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Logout process
if (isset($_GET['logout'])) {
    // Destroy the session and redirect to the login page
    session_destroy();
    header('Location: login.php');
    exit();
}

// Retrieve categories for the specific event from the database
$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$eventId = 1; // Replace with the actual event ID
$sql = "SELECT * FROM categories WHERE event_id = $eventId";
$result = $conn->query($sql);

$categories = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row['category_name'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Categories</title>
    <style>
        body {
            background-color: #349bdf;
            color: #fff;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        .category-list {
            list-style-type: none;
            padding: 0;
        }

        .category-list li {
            margin-bottom: 10px;
        }

        .add-payment-btn {
            background-color: #a7d3f1;
            color: #0a2b43;
            border: none;
            border-radius: 4px;
            padding: 5px 10px;
            text-decoration: none;
        }

        .add-payment-btn:hover {
            background-color: #0a2b43;
            color: #fff;
        }

        .logout-btn {
            display: block;
            margin-top: 20px;
            color: #fff;
            background-color: #a7d3f1;
            padding: 10px;
            border: none;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #0a2b43;
        }
    </style>
</head>
<body>
    <h2>Categories</h2>

    <ul class="category-list">
        <?php foreach ($categories as $category) { ?>
            <li>
                <?php echo $category; ?>
                <a class="add-payment-btn" href="add_payment.php?eventId=<?php echo $eventId; ?>&category=<?php echo urlencode($category); ?>">Add Payment</a>
            </li>
        <?php } ?>
    </ul>

    <!-- Logout button -->
    <a class="logout-btn" href="category.php?logout=true">Logout</a>
</body>
</html>
