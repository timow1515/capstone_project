<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit();
}

// Connect to the database
$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve user information
$email = $_SESSION['email'];
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $address = $row['address'];
    // ... retrieve other columns as needed
} else {
    // Handle the case when user information is not found
    // Redirect or display an error message
}

// Update user profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $address = $_POST['address'];
    // ... get other updated user information

    // Update the user's profile information in the database
    $updateSql = "UPDATE users SET name = '$name', address = '$address' WHERE email = '$email'";
    if ($conn->query($updateSql) === TRUE) {
        // Redirect to the profile page after successful update
        header('Location: user_profile.php');
        exit();
    } else {
        // Handle the case when the update fails
        // Redirect or display an error message
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Profile</title>
    <!-- Add your CSS styles here -->
</head>
<body>
    <h1>Update Profile</h1>

    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>
        <br><br>
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" value="<?php echo $address; ?>" required>
        <br><br>
        <!-- Add other input fields for updating user information -->
        <input type="submit" value="Update">
    </form>
</body>
</html>
