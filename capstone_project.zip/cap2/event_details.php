<?php
// Connect to the database
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve event details from the database
$eventId = $_GET['id']; // Assuming you're passing the event ID through a query parameter
$sql = "SELECT * FROM events WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $eventId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $event = $result->fetch_assoc();
    $title = $event['title'];
    $description = $event['description'];
    $maxParticipants = $event['max_participants'];
    $paymentAmount = $event['payment_amount'];
    $organizerName = $event['organizer_name'];
    $category = $event['category'];
} else {
    // Event not found
    echo 'Event not found';
    $stmt->close();
    $conn->close();
    exit();
}

$stmt->close();

// Retrieve available categories from the event's category column
$categories = explode(',', $category);

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Event Details</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .event-details {
            margin-bottom: 20px;
        }

        .event-details label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .event-details span {
            display: block;
            margin-bottom: 10px;
        }

        .categories {
            margin-bottom: 20px;
        }

        .categories label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .categories .category-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        .categories .category-button:hover {
            background-color: #064976;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Event Details</h1>

        <div class="event-details">
            <label>Title:</label>
            <span><?php echo $title; ?></span>

            <label>Description:</label>
            <span><?php echo $description; ?></span>

            <label>Max Participants:</label>
            <span><?php echo $maxParticipants; ?></span>

            <label>Payment Amount:</label>
            <span><?php echo $paymentAmount; ?></span>

            <label>Organizer Name:</label>
            <span><?php echo $organizerName; ?></span>
        </div>

        <div class="categories">
            <label>Categories:</label>
            <?php
            foreach ($categories as $category) {
                echo '<a class="category-button" href="payment.php?category=' . $category . '">Join ' . $category . '</a>';
            }
            ?>
        </div>

        <div>
            <a class="back-button" href="home_lobby.php">Back</a>
        </div>
    </div>
</body>
</html>
