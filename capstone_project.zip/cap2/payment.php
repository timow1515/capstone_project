<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 100px;
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
            color: #333;
            font-weight: bold;
        }

        input[type="text"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #064976;
        }

        .back-button {
            text-align: center;
            margin-top: 20px;
        }

        .back-button a {
            color: #0a2b43;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment Page</h1>
        <form action="process_payment.php" method="post">
            <label for="paypal_email">PayPal Email:</label>
            <input type="text" id="paypal_email" name="paypal_email" required>

            <label for="amount">Amount:</label>
            <input type="text" id="amount" name="amount" required>

            <input type="submit" value="Pay Now">
        </form>
        <div class="back-button">
            <a href="javascript:history.back()">Back</a>
        </div>
    </div>

    <script>
        // Check if the payment was successful and redirect to the upload page
        var params = new URLSearchParams(window.location.search);
        if (params.has('success') && params.get('success') === 'true') {
            window.location.href = 'upload_entry.php';
        }
    </script>
</body>
</html>
