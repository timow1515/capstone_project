<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Generate a unique code
$uniqueCode = generateUniqueCode();

// Function to generate a unique code
function generateUniqueCode() {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $codeLength = 8;
    $code = '';

    for ($i = 0; $i < $codeLength; $i++) {
        $index = rand(0, strlen($characters) - 1);
        $code .= $characters[$index];
    }

    return $code;
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file_upload'])) {
    $targetDir = 'uploads/';
    $targetFile = $targetDir . basename($_FILES['file_upload']['name']);
    $uploadOk = 1;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if the file is an actual file
    if ($_FILES['file_upload']['size'] > 0) {
        $uploadOk = 1;
    } else {
        echo 'Error: Please select a file to upload.';
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES['file_upload']['size'] > 5000000) {
        echo 'Error: File size is too large. Maximum file size is 5MB.';
        $uploadOk = 0;
    }

    // Allow only certain file formats
    $allowedFormats = ['jpg', 'jpeg', 'png', 'mp4'];
    if (!in_array($fileType, $allowedFormats)) {
        echo 'Error: Only JPG, JPEG, PNG, and MP4 files are allowed.';
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk === 0) {
        echo 'Error: File was not uploaded.';
    } else {
        if (move_uploaded_file($_FILES['file_upload']['tmp_name'], $targetFile)) {
            echo 'File has been uploaded successfully.';
        } else {
            echo 'Error: There was an error uploading the file.';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submission Page</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        .submission-form {
            margin-bottom: 20px;
        }

        .submission-form label {
            font-weight: bold;
        }

        .submission-form input[type="file"] {
            margin-bottom: 15px;
        }

        .submission-form input[type="submit"] {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .submission-form input[type="submit"]:hover {
            background-color: #2980b9;
        }

        .unique-code {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Submission Page</h1>

        <div class="submission-form">
            <form action="submission_page.php" method="POST" enctype="multipart/form-data">
                <label for="file_upload">Upload a Video or Photo:</label>
                <input type="file" name="file_upload" accept="image/*,video/*"><br>

                <input type="submit" value="Submit">
            </form>
        </div>

        <div class="unique-code">
            <p>Unique Code: <?php echo $uniqueCode; ?></p>
        </div>

        <p><a href="payment_page.php">Back to Payment Page</a></p>
    </div>
</body>
</html>
