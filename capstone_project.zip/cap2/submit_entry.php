<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Handle the entry submission form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $eventID = $_POST['eventID'];
    $entryType = $_POST['entryType'];

    // Perform necessary validation checks

    // Insert the entry into the database
    $servername = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $dbname = 'db_cs2';

    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Code to handle file upload and saving the entry file

    $sql = "INSERT INTO entries (event_id, user_id, entry_type, entry_file) VALUES ('$eventID', '$_SESSION[userid]', '$entryType', 'file_path')";
    if ($conn->query($sql) === true) {
        echo "Entry submitted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!-- Entry submission form -->
<form action="submit_entry.php" method="POST" enctype="multipart/form-data">
    <input type="text" name="eventID" placeholder="Event ID" required><br>
    <select name="entryType">
        <option value="video">Video</option>
        <option value="photo">Photo</option>
    </select><br>
    <input type="file" name="file" required><br>
    <input type="submit" value="Submit Entry">
</form>
