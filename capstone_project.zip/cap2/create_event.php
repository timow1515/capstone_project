<!DOCTYPE html>
<html>
<head>
    <title>Create Event</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group textarea {
            height: 100px;
        }

        .form-group .button-container {
            text-align: center;
        }

        .form-group .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .form-group .button:hover {
            background-color: #064976;
        }

        .back-button {
            text-align: center;
            margin-top: 20px;
        }

        .back-button .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .back-button .button:hover {
            background-color: #064976;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Event</h1>

        <form method="POST" action="process_create_event.php">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" name="title" id="title" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" id="description" required></textarea>
            </div>

            <div class="form-group">
                <label for="max_participants">Max Participants:</label>
                <input type="number" name="max_participants" id="max_participants" required>
            </div>

            <div class="form-group">
                <label for="payment_amount">Payment Amount:</label>
                <input type="number" name="payment_amount" id="payment_amount" required>
            </div>

            <div class="form-group">
                <label for="organizer_name">Organizer Name:</label>
                <input type="text" name="organizer_name" id="organizer_name" required>
            </div>

            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" name="category" id="category" required>
            </div>

            <div class="form-group button-container">
                <input type="submit" class="button" value="Create">
            </div>
        </form>

        <div class="back-button">
            <a class="button" href="home_lobby.php">Back</a>
        </div>
    </div>
</body>
</html>
