<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Handle the logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Connect to the database
$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve the list of events
$sql = 'SELECT * FROM events';
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Home Lobby</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .event {
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .event-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .event-organizer {
            color: #666;
            margin-bottom: 10px;
        }

        .event-description {
            margin-bottom: 10px;
        }

        .event-date {
            color: #999;
        }

        .event-actions {
            text-align: right;
        }

        .join-button {
            display: inline-block;
            padding: 5px 10px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .join-button:hover {
            background-color: #064976;
        }

        .create-button {
            text-align: center;
            margin-bottom: 20px;
        }

        .logout-button {
            text-align: center;
        }

        .profile-button {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Guppy Show Contest</h1>

        <div class="create-button">
            <a class="join-button" href="create_event.php">Create Event</a>
        </div>

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="event">';
                echo '<div class="event-title">' . $row['title'] . '</div>';
                echo '<div class="event-organizer">Organized by: ' . $row['organizer_name'] . '</div>';
                echo '<div class="event-description">' . $row['description'] . '</div>';
                echo '<div class="event-date">Date: ' . $row['date'] . '</div>';
                echo '<div class="event-actions">';
                echo '<a class="join-button" href="event_details.php?id=' . $row['id'] . '">Join</a>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No events available.</p>';
        }
        ?>

        <div class="logout-button">
            <a class="join-button" href="?action=logout">Logout</a>
        </div>

        <div class="profile-button">
            <a class="join-button" href="user_profile.php">Profile</a>
        </div>
    </div>
</body>
</html>
<div class="profile-picture">
    <?php
    if (isset($_SESSION['profile_picture']) && file_exists($_SESSION['profile_picture'])) {
        echo '<img src="' . $_SESSION['profile_picture'] . '" alt="Profile Picture">';
    }
    ?>
</div>

<?php
$conn->close();
?>
