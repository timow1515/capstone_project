<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Logout process
if (isset($_GET['logout'])) {
    // Destroy the session and redirect to the login page
    session_destroy();
    header('Location: login.php');
    exit();
}

$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

// Retrieve event details from the database
$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

$eventId = isset($_GET['eventId']) ? $_GET['eventId'] : '';
$organizerName = $_SESSION['username'];

$sql = "SELECT * FROM events WHERE id = '$eventId' AND organizer_name = '$organizerName'";
$result = $conn->query($sql);

$event = $result->fetch_assoc();

$conn->close();

// Handle event update form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $eventDescription = isset($_POST['eventDescription']) ? $_POST['eventDescription'] : '';
    $category = isset($_POST['category']) ? $_POST['category'] : '';

    // Update event description in the database
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $sql = "UPDATE events SET description = '$eventDescription' WHERE id = '$eventId' AND organizer_name = '$organizerName'";
    if ($conn->query($sql) === true) {
        // Event description updated successfully
        header("Location: manage_event.php?eventId=$eventId");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Event</title>
    <style>
        body {
            background-color: #349bdf;
            color: #fff;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form {
            max-width: 400px;
        }

        input[type="text"],
        textarea,
        input[type="number"],
        select,
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 4px;
            background-color: #a7d3f1;
            color: #0a2b43;
        }

        input[type="submit"]:hover {
            background-color: #0a2b43;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-btn {
            display: block;
            margin-top: 20px;
            color: #fff;
            background-color: #a7d3f1;
            padding: 10px;
            border: none;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #0a2b43;
        }
    </style>
</head>
<body>
    <h2>Manage Event</h2>

    <!-- Event details -->
    <h3><?php echo $event['title']; ?></h3>
    <p><?php echo $event['description']; ?></p>

    <!-- Update event description form -->
    <form action="manage_event.php?eventId=<?php echo $eventId; ?>" method="POST">
        <textarea name="eventDescription" placeholder="Update Event Description" required></textarea><br>
        <input type="submit" value="Update Description">
    </form>

    <!-- Categories -->
    <h3>Categories</h3>
    <?php
    // Retrieve categories for the event from the database
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $sql = "SELECT * FROM event_categories WHERE event_id = '$eventId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>" . $row['category'] . "</p>";
        }
    } else {
        echo "<p>No categories found.</p>";
    }

    $conn->close();
    ?>

    <!-- Add category form -->
    <form action="add_category.php?eventId=<?php echo $eventId; ?>" method="POST">
        <input type="text" name="category" placeholder="Add Category" required><br>
        <input type="submit" value="Add Category">
    </form>

    <!-- Logout button -->
    <a class="logout-btn" href="manage_event.php?eventId=<?php echo $eventId; ?>&logout=true">Logout</a>
</body>
</html>
