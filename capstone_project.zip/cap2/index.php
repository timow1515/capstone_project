<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Contest System</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>! This is the contest system.</h1>

    <!-- Display the available events and their details -->
    <h2>Available Events:</h2>
    <ul>
        <li>Event 1</li>
        <li>Event 2</li>
        <li>Event 3</li>
        <!-- Add more events dynamically from the database -->
    </ul>

    <!-- Create an event lobby -->
    <h2>Create Event Lobby:</h2>
    <form action="create_event.php" method="POST">
        <input type="text" name="event_name" placeholder="Event Name" required><br>
        <textarea name="event_description" placeholder="Event Description" required></textarea><br>
        <!-- Add more event details fields if needed -->
        <input type="submit" value="Create Event">
    </form>

    <!-- Display the user's entries and their details -->
    <h2>Your Entries:</h2>
    <ul>
        <li>Entry 1</li>
        <li>Entry 2</li>
        <li>Entry 3</li>
        <!-- Add more entries dynamically from the database -->
    </ul>

    <!-- Submit an entry -->
    <h2>Submit Entry:</h2>
    <form action="submit_entry.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="entry_file" required><br>
        <!-- Add more entry details fields if needed -->
        <input type="submit" value="Submit Entry">
    </form>

    <!-- Display the evaluations and their details -->
    <h2>Evaluations:</h2>
    <ul>
        <li>Evaluation 1</li>
        <li>Evaluation 2</li>
        <li>Evaluation 3</li>
        <!-- Add more evaluations dynamically from the database -->
    </ul>

    <!-- Perform evaluation -->
    <h2>Perform Evaluation:</h2>
    <form action="perform_evaluation.php" method="POST">
        <input type="hidden" name="entry_id" value="entry_id"> <!-- Replace with the actual entry ID -->
        <input type="text" name="label" placeholder="Label" required><br>
        <input type="text" name="badge" placeholder="Badge" required><br>
        <!-- Add more evaluation details fields if needed -->
        <input type="submit" value="Perform Evaluation">
    </form>

    <!-- Add payment -->
    <h2>Add Payment:</h2>
    <form action="add_payment.php" method="POST">
        <input type="hidden" name="entry_id" value="entry_id"> <!-- Replace with the actual entry ID -->
        <input type="text" name="amount" placeholder="Amount" required><br>
        <!-- Add more payment details fields if needed -->
        <input type="submit" value="Add Payment">
    </form>

    <!-- Logout -->
    <form action="logout.php" method="POST">
        <input type="submit" value="Logout">
    </form>
</body>
</html>
